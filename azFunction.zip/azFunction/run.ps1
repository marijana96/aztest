# Input bindings are passed in via param block.
param([byte[]] $InputBlob, $TriggerMetadata)

# Write out the blob name and size to the information log.
Write-Host "PowerShell Blob trigger function Processed blob! Name: $($TriggerMetadata.Name) Size: $($InputBlob.Length) bytes"


# Define source, source contains the blob newly uploaded(with file name)
$SourceURI = "https://stgmmvtestsrc.blob.core.windows.net/"
$SourceBlobContainer = "ooto/"
$SourceSASToken = "?sv=2022-11-02&ss=bfqt&srt=sco&sp=rwlacutfx&se=2023-05-09T15:57:52Z&st=2023-05-08T07:57:52Z&spr=https&sig=bNclPwveG3H0hC1YGCcOJwiQwn9lu4poQE85fh8aZJ0%3D"
$SourceFullPath = "$($SourceURI)$($SourceBlobContainer)$($TriggerMetadata.Name)$($SourceSASToken)"


# Define dest, dest is only the full container name
$DestStgAccURI = "https://stgmmvtstdest.blob.core.windows.net/"
$DestBlobContainer = "ooto/"
$DestSASToken = "?sv=2022-11-02&ss=bfqt&srt=sco&sp=rwlacux&se=2023-05-09T15:58:37Z&st=2023-05-08T07:58:37Z&spr=https&sig=pMB8T%2B1YHF0dkrg2xYZYwfzDrkXFisRY39ATsORCoSw%3D"
$DestFullPath = "$($DestStgAccURI)$($DestBlobContainer)$($DestSASToken)"



# del azcopy.exe and download lastest version of azcopy
# del azcopy.exe

# Test if AzCopy.exe exists in current folder
$AzcoypFile = "azcopy.exe"
$AzCopyExists = Test-Path $AzcoypFile
Write-Host "AzCopy exists:" $AzCopyExists

# Download AzCopy.zip and unzip if it doesn't exist
If ($AzCopyExists -eq $False)
{
    Write-Host "AzCopy not found. Downloading..."
    
    #Download AzCopy
    Invoke-WebRequest -Uri "https://aka.ms/downloadazcopy-v10-windows" -OutFile AzCopy.zip -UseBasicParsing
 
    #unzip azcopy
    write-host "unzip azcopy.zip"
    Expand-Archive ./AzCopy.zip ./AzCopy -Force

    # Copy AzCopy to current dir
    Get-ChildItem ./AzCopy/*/azcopy.exe | Copy-Item -Destination "./AzCopy.exe"
}


# Run AzCopy from source blob to destination blob 

Write-Host "copy blob from  $($SourceFullPath) to  $($DestFullPath)"
./azcopy.exe copy $SourceFullPath $DestFullPath --recursive=true